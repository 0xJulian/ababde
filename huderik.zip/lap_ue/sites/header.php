<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="de">
<title>WebShop</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="./../src/css/styles.css">
<link rel="stylesheet" href="./../src/css/navbar.css">

<div id="navbar">
    <ul style="display: flex;">
        <li> <a href="../index.php" class="bar-item button padding-large white">Home</a></li>
        <li> <a href="../sites/allProducts.php" class="bar-item button padding-large white">Products</a></li>
        <div style="flex-grow: 1;"></div>
        <?php if (isset($_SESSION['userId'])): ?>
            <li><a href="./../sites/cart.php" class="bar-item button padding-large white">Cart</a></li>
            <li><a href="./../sites/logout.php" class="bar-item button padding-large white">Logout</a></li>
        <?php else: ?>
            <li><a href="../sites/register.php" class="bar-item button padding-large white">Register</a></li>
            <li><a href="../sites/login.php" class="bar-item button padding-large white">Login</a></li>
        <?php endif; ?>
    </ul>
</div>
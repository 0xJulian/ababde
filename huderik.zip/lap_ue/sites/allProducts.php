<div> 

    <div id="navbar">
        <?php   
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            include('../sites/header.php');
        ?>
    </div>
    <div>
        <h1 style="text-align: center;">Alle Produkte</h1>
        <div>
            <?php
            
            require_once('../classes/product.php');

            if (isset($_POST['details'])) {
                $productId = $_POST['productId'];
                $product = Product::getProduct($productId);
                
                // Speichern des Produkts in der Session
                $_SESSION['viewProduct'] = $product;
                
                header("Location: ./viewProduct.php", true, 301);
                
            }if (isset($_POST['cart'])) {
                $productId = $_POST['productId'];
                $userId = $_SESSION['userId'];
                $product = Product::addCart($productId, $userId);
                
                //header("Location: ./cart.php", true, 301);
            }
            
            $products = Product::getAllProducts();?>
            <div style="display: flex; flex-direction: row;">
            <?php
            foreach($products as $product){
                echo "<form method='post' class='product' action=''>"; // Form start

                    echo "<div>";
                        echo "<h2>{$product['name']}</h2>";
                        echo "<p>Preis: {$product['price']}</p>";
                        echo "<p>Beschreibung: {$product['description']}</p>";
                        echo "<input type='hidden' name='productId' value='{$product['id']}'>";
                        echo "<input type='submit' name='cart' value='In den Warenkorb'>";
                        echo "<input type='submit' name='details' value='Details'>";
                    echo "</div>";
                echo "</form>"; // Form end

            }
            ?>
            </div>
        </div>
    </div>
    <footer>
        <?php
        include("../sites/footer.php")
        ?>
    </footer>
</div>
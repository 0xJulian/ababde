<head>
    <?php
    include('../sites/header.php');
    ?>
</head>
<div id="">


<?php

require_once ('../classes/user.php');

$showFormular = true; //Variable ob das Registrierungsformular anezeigt werden soll

if(isset($_GET['register'])) {
    
    $registrationResult = User::register($_POST);

    if($registrationResult == 'success') {
        echo 'Du wurdest erfolgreich registriert. <a href="allProducts.php">Zum Login</a>';
        $showFormular = false;
    } else {
        echo $registrationResult . '<br>';
    }
}


if($showFormular) {
?>

<form action="?register=1" method="post" >

<h1 class="form-group">Registrieren</h1>

<div class="form-group">
<label for="inputVorname">Vorname:</label>
<input type="text" id="inputVorname" size="40" maxlength="250" name="vorname" class="form-control" required>
</div><br>

<div class="form-group">
<label for="inputNachname">Nachname:</label>
<input type="text" id="inputNachname" size="40" maxlength="250" name="nachname" class="form-control" required>
</div><br>

<div class="form-group">
<label for="inputEmail">E-Mail:</label>
<input type="email" id="inputEmail" size="40" maxlength="250" name="email" class="form-control" required>
</div><br>

<div class="form-group">
<label for="inputPasswort">Dein Passwort:</label>
<input type="password" id="inputPasswort" size="40"  maxlength="250" name="passwort" class="form-control" required>
</div> <br>

<div class="form-group">
<label for="inputPasswort2">Passwort wiederholen:</label>
<input type="password" id="inputPasswort2" size="40" maxlength="250" name="passwort2" class="form-control" required>
</div> <br>

<div class="form-group">
<label for="inputEmail">Postleitzahl:</label>
<input type="postalCode" id="inputPostalCode" size="40" maxlength="250" name="postalCode" class="form-control" required>
</div><br>

<div class="form-group">
<label for="inputEmail">Stadt:</label>
<input type="city" id="inputCity" size="40" maxlength="250" name="city" class="form-control" required>
</div><br>

<div class="form-group">
<label for="inputEmail">Straße:</label>
<input type="street" id="inputStreet" size="40" maxlength="250" name="street" class="form-control" required>
</div><br><br>
<div class="form-group-btn">
<button type="submit">Registrieren</button>
</div>
</form>
 
<?php
} //Ende von if($showFormular)
	

?>
</div>
<footer>
        <?php
        include("./../sites/footer.php")
        ?>
    </footer>
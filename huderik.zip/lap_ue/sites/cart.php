<div> 
    <div id="navbar">
        <?php   
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            include('../sites/header.php');
        ?>
    </div>
    <div>
        <h1>Dein Warenkorb</h1>
        <div>
            <?php
            require_once('../classes/product.php');
            $products = Product::getCart($_SESSION['userId']);
            $counter = 0; // Initialize counter
            $summe = 0;
            ?>
            <div style="display: flex; flex-direction: row;"> <!-- Start of the first row -->
                <?php
                foreach($products as $product){
                    if ($counter % 5 == 0 && $counter != 0) { // Every 5 products, but not the first time
                        echo "</div><div style='display: flex; flex-direction: row;'>"; // Close the current row and start a new one
                    }
                    echo "<form method='post' class='product'>"; // Form start
                        echo "<div>";
                            echo "<h2>{$product['name']}</h2>";
                            echo "<p>Preis: {$product['price']}</p>";
                            echo "<input type='hidden' name='productId' value='{$product['id']}'>";
                            echo "<input type='submit' name='cart' value='In den Warenkorb'>";
                            echo "<input type='submit' name='details' value='Details'>";
                        echo "</div>";
                    echo "</form>"; // Form end
                    $counter++; // Increment counter
                }
                ?>
            </div> <!-- End of the last row -->
        </div>
    </div>
    <div class='list'>
    <?php
        foreach($products as $product){
           
             // Close the current row and start a new one
            
            echo "<form method='post' >"; // Form start
                echo "<div>";
                    echo "<p>{$product['name']}   Preis: {$product['price']}€</p>";
                    $summe = $summe + $product['price'];
                    //echo "<p>Preis: {$product['price']}</p>";
                echo "</div>";
            echo "</form>"; // Form end
            $counter++; // Increment counter
        }
        echo "<p>";
        echo "<p class='list'> Summe: ".$summe;
        ?>

    </div>
    <div>
    <?php
    
        echo "<form method='post' class='button-3' style='text-align:right; margin-right:10%; padding: 5px,5px,5px,5px; ' class='product'>";
        echo "<input type='submit' name='order' value='Bestellen'>";
        echo "</form>";
    ?>
    </div>
    <footer>
        <?php
        include("../sites/footer.php")
        ?>
    </footer>
</div>
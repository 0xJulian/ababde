<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once('../modules/config.php');
require_once ('../classes/user.php');

// Checks if the login form is submited
if (isset($_GET['login'])) {
    // Calls the login method from the user class
    $id = User::login($_POST);
    // If the login was successful, the user gets redirected to the allProducts site
    // Checks if the user is set and not false and redirects to the userSite.php 
    if ($id !== false) {

        header("Location: ./allProducts.php", true, 301);
    } else {
        // Dispays an error if the user is invalide 
        $errorMessage = "E-Mail oder Passwort war ungültig<br>";
    }
}
?>

<body>
    <div id="navbar">
            <?php include('../sites/header.php');?>
    </div>
    <!-- Content -->
    <?php
    // Displays an error message on the top of the site if one is set 
    if (isset($errorMessage)) {
        echo $errorMessage;
    }
    ?>
    <!-- Div that centers the displayed login form -->
    <div style=" display: block;margin-left: auto;margin-right: auto;width: max-content;">
        <form action="?login=1" method="post">
            E-Mail:<br>
            <input type="email" size="40" maxlength="250" name="email"><br><br>
            Dein Passwort:<br>
            <input type="password" size="40" maxlength="250" name="passwort"><br>
            <input type="submit" value="Abschicken">
        </form>
    </div>
    <!-- Footer -->
    <footer>
        <div>
            <p>LAP (c) 2024</p>
        </div>
    </footer>
</body>

</html>
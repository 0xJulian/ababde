<div class="center">
<?php
include('../sites/header.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['viewProduct'])) {
    $product = $_SESSION['viewProduct'];
    
    // Zeigen Sie hier die Produktdetails an
    echo "<h2>" . htmlspecialchars($product['name']) . "</h2>";
    echo "<p>Preis: " . htmlspecialchars($product['price']) . "</p>";
    echo "<p>Beschreibung: " . htmlspecialchars($product['description']) . "</p>";
    
  
}
?>
</div>
<?php

require_once('../classes/database.php');


define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'lap_ue1');

?>

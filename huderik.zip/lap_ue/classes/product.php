<?php
require_once 'database.php';
// Definition of the user class
class Product {
	// represents the database rable
	public $productId;
	public $name;
	public $description;
	public $price;
    public $stock;

	public static function getAllProducts() {
		
		$db = Database::getInstance();
        $conn = $db->getConnection();

        $sql = "SELECT * FROM products";
        $products = mysqli_query($conn, $sql);
        return $products;
    }

	public static function getProduct($id){

		$db = Database::getInstance();
        $conn = $db->getConnection();

        $sql = "SELECT * FROM products WHERE id = '$id'";
        $product = mysqli_query($conn, $sql);
		$product = mysqli_fetch_assoc($product);
		if($product) {

			return $product;
		} else {
			return 'Es ist leider ein Fehler aufgetreten';
		}
        return $product;
	}

	public static function addCart($productId, $userId){
		if(self::getProduct($productId)){

			$db = Database::getInstance();
			$conn = $db->getConnection();
			$statement = $conn->prepare("INSERT INTO cart (productId, userId) VALUES (?, ?)");
			$statement->bind_param("ss", $productId, $userId);
			$result = $statement->execute();

		}else{
			return 'Produkt existiert nicht in Datenbank!';
		}
	}

	public static function getCart($userId){
		
		$db = Database::getInstance();
		$conn = $db->getConnection();
		
		$sql = "SELECT * FROM cart WHERE userId = '$userId'";

		$result = mysqli_query($conn, $sql);
		//$h = mysqli_fetch_assoc($result[0]);
		
		
		$products = [];
		
		
		while ($row = mysqli_fetch_assoc($result)) { 
			$product = self::getProduct($row['productId']);
			if ($product) {
				array_push($products, $product);
			}
		}
		
		return $products;
	}

}
?>
<?php
// Definition of the user class
class User {
	// represents the database rable
	public $userId;
	public $email;
	public $firstname;
	public $lastname;
	public $postalCode;
	public $city;
	public $street;

	public static function register($userData) {
        $db = Database::getInstance();
        $conn = $db->getConnection();

		$vorname = trim($userData['vorname']);
    	$nachname = trim($_POST['nachname']);
    	$email = trim($_POST['email']);
    	$postalCode = trim($_POST['postalCode']);
    	$city = trim($_POST['city']);
    	$street = trim($_POST['street']);
    	$passwort = $_POST['passwort'];
    	$passwort2 = $_POST['passwort2'];
        
		if(empty($vorname) || empty($nachname) || empty($email) || empty($postalCode) || empty($city) || empty($street)) {
			return 'Bitte alle Felder ausfüllen';
		}
	
		$statement = $conn->prepare("SELECT * FROM users WHERE email = ?");
		$statement->bind_param("s", $email);
		$statement->execute();
		$result = $statement->get_result();
		if($result->num_rows > 0) {
			return 'Diese E-Mail-Adresse ist bereits vergeben';
		}
	
		$passwort_hash = password_hash($passwort, PASSWORD_DEFAULT);
		$statement = $conn->prepare("INSERT INTO users (email, password, firstname, lastname, postalCode, city, street) VALUES (?, ?, ?, ?, ?, ?, ?)");
		$statement->bind_param("sssssss", $email, $passwort_hash, $vorname, $nachname, $postalCode, $city, $street);
		$result = $statement->execute();
	
		if($result) {
			return 'success';
		} else {
			return 'Beim Abspeichern ist leider ein Fehler aufgetreten';
		}
    }

    public static function login($userData) {
		
        $db = Database::getInstance();
        $conn = $db->getConnection();

		$email = $userData['email'];
		$password = $userData['passwort'];
        $user = self::getUser($email);

        if ($user) {
            if (password_verify($password, $user->password)) {
				$_SESSION['userId'] = $user->id; // Corrected line
                return "success";
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

	public static function getUser($email) {
		$db = Database::getInstance();
		$conn = $db->getConnection();
		// Prepare db-statements using prepared statements to prevent SQL injection
		
        
		$statement = $conn->prepare("SELECT * FROM users WHERE email = ?;");
		$statement->bind_param("s", $email);
		$statement->execute();
		$result = $statement->get_result();
		if ($result->num_rows > 0) {
			return $result->fetch_object(); // Fetch the result as an object
		} else {
			return null; // Return null if no user found
		}
	}
	public static function logout($userData) {
		$_SESSION = array();
		header("Location: ./logout.php", true, 301);
        session_destroy();
    }
}

?>
<?php
require_once ('../classes/user.php');
require_once('../modules/config.php');
class Database {
    // Private variable that can only be called inside the class and it's child objects
    private static $instance = null;
    private $conn;
    // The constructor gets called when the class gets created
    private function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        // Error handling or exception
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // The public static method that returns the instance of the class
    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Method to get the database connection
    public function getConnection() {
        return $this->conn;
    }
}
